To Install.

1) Run the SQLServerCE installer(s).

	If you have a 64-bit version of windows, you will need to run
	both SQLServerCE installers. 32-bit first, and 64-bit second.

	If you have a 32-bit version of windows you only need run the 
	32-bit version of the SQLServerCE Installer.

	If you don't know if you have 32-bit or 64-bit go ahaed and 
	run both installers. The 64-bit installer will nicely tell 
	you if you don't have a 64-bit version of windows and not
	install.


2) Make a directory where you want Family Finance 2 to keep
it's data base file. 
	
	I suggest a directory like the following.
	C:\Users\Public\Documents\Finances\FamilyFinance

	-Note there will be two files going into this directory.
		*FamilyFinance2.exe <- The program
		*FamilyFinanceDB.sdf <- The database file.
	These files will be relatively small. Definatly less than 1Mb 
	initially.


3) Copy the FamilyFinance2.exe file into this directory.

4) Right-Click the new FamilyFinance2.exe file and select "Copy"

5) Right-Click your desktop and select "Paste Shortcut"

6) Double click your new FamilyFinance2 Icon / Shortcut.

7) Select the "Create New File" and navigate to the directory you made 
in step 2. The program will make it's own data base file and start up.



Let me know if you have any problems or questions.
